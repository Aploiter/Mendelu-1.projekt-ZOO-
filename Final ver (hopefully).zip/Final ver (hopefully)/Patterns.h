#ifndef PATTERNS_H
#define PATTERNS_H

#include <vector>
#include <string>
#include <initializer_list>
#include <iostream>

namespace Patterns {

    struct CellPattern {
        std::vector<std::string> lines;

        CellPattern(const std::initializer_list<std::string>& data)
            : lines(data) {}

        void print() const;
    };

    // Deklarace všech vzorů
    extern const CellPattern H0D0L0R0;
    extern const CellPattern H0D1L0R0;
    extern const CellPattern H1D0L0R0;
    extern const CellPattern H0D0L1R0;
    extern const CellPattern H0D0L0R1;
    extern const CellPattern H0D1L0R1;
    extern const CellPattern H0D1L1R0;
    extern const CellPattern H1D1L0R0;
    extern const CellPattern H1D0L1R0;
    extern const CellPattern H1D0L0R1;
    extern const CellPattern H0D0L1R1;
    extern const CellPattern H1D1L1R0;
    extern const CellPattern H1D1L0R1;
    extern const CellPattern H1D0L1R1;
    extern const CellPattern H0D1L1R1;
    extern const CellPattern H1D1L1R1;
    extern const CellPattern H0D0L1R1EXIT;

} // namespace Patterns

#endif // PATTERNS_H

#include "TitleMenu.h"

int main()
{
    TitleMenu title; // vytvoření objektu hlavního menu (TitleMenu) na zásobníku.
    title.print(); // volá metodu print z objektu (title)

    return 0;
}

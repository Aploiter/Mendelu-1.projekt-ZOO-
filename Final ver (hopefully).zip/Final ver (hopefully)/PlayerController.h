#ifndef PLAYERCONTROLLER_H
#define PLAYERCONTROLLER_H

#include "Map.h"

class PlayerController
{
public:
    explicit PlayerController(Map& map);

    void runMovement();

private:
    Map& map;
};

#endif

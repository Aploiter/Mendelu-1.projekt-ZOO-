#include "PlayerController.h"

#include <iostream>
#include <ostream>
#include <windows.h>

PlayerController::PlayerController(Map& map)
    : map(map) {}

void PlayerController::runMovement() {
    bool moving = true;
    char input;

    while (moving) {
        system("cls");       // Vyčistí obrazovku
        Sleep(1000);
        map.printMap();      // Vykreslí mapu

        if (map.isPlayerAtExit()) {
            std::cout << "\nYou've reached the end!\n";
            Sleep(2000);
            return;
        }

        std::cout << "\nWASD = movement | Q = return to menu\n";
        std::cin >> input;

        switch (input) {
            case 'w': case 'W': map.movePlayer(Direction::UP); break;
            case 's': case 'S': map.movePlayer(Direction::DOWN); break;
            case 'a': case 'A': map.movePlayer(Direction::LEFT); break;
            case 'd': case 'D': map.movePlayer(Direction::RIGHT); break;
            case 'q': case 'Q': moving = false; break;
            default: std::cout << "Invalid input\n"; break;
        }
    }
}


#ifndef INGAMEMENU_H
#define INGAMEMENU_H

#include "Map.h"

class IngameMenu
{
private:
    Map map;
public:
    IngameMenu(); // konstruktor
    //metody pro akce v menu
    void print();
    void loadSave();
    void returnToTitle();
    void exitGame();
    void playerInfo();
    void Move();
    void viewInventory();
};

#endif //INGAMEMENU_H